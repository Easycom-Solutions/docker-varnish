#!/bin/sh

FLOPS='
	*.c
'

. ../../tools/flint_skel.sh
