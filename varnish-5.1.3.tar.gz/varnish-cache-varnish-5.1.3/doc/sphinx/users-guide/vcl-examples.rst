
VCL Examples
------------

These are a short collection of examples that showcase some of the
capabilities of the VCL language.

.. toctree::

  vcl-example-manipulating-headers
  vcl-example-manipulating-responses
  vcl-example-acls
  vcl-example-websockets


