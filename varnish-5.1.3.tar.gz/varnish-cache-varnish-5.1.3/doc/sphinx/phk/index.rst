.. _phk:

Poul-Hennings random outbursts
==============================

You may or may not want to know what Poul-Henning thinks.

.. toctree::
	:maxdepth: 1

	trialerror.rst
	farfaraway.rst
	thatslow.rst
	firstdesign.rst
	10goingon50.rst
	brinch-hansens-arrows.rst
	ssl_again.rst
	persistent.rst
	dough.rst
	wanton_destruction.rst
	spdy.rst
	http20.rst
	varnish_does_not_hash.rst
	thetoolsweworkwith.rst
	three-zero.rst
	ssl.rst
	gzip.rst
	vcl_expr.rst
	ipv6suckage.rst
	backends.rst
	platforms.rst
	barriers.rst
	thoughts.rst
	autocrap.rst
	sphinx.rst
	notes.rst

