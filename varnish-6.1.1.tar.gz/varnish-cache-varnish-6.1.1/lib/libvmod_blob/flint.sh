#!/bin/sh

FLOPS='
	-I../../bin/varnishd
	*.c
'

. ../../tools/flint_skel.sh
